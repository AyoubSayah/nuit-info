export type Ttheme = "autumn" | "spring" | "summer" | "winter" | "custom";
