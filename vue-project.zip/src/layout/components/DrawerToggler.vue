<template>
  <div
    class="fixed right-0 top-1/2 h-11 w-11 -translate-y-1/2 cursor-pointer rounded-l-md border-2 border-r-0 border-theme-secondary bg-theme-primary fill-theme-secondary p-2 shadow-xl transition-all hover:border-theme-primary hover:bg-theme-secondary hover:fill-theme-primary"
  >
    <icon-base class="h-6 w-6" icon-name="icon-cogs" />
  </div>
</template>
<script lang="ts" setup>
import IconBase from "../../components/base/icon/IconBase.vue";
</script>
