import type { Ttheme } from "@/utils/types/theme-type";

export const themesData: Ttheme[] = [
  "autumn",
  "spring",
  "summer",
  "winter",
  "custom",
];
