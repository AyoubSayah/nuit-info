export interface IshopItem {
  id?: number;
  name: string;
  price: string;
  img: string;
  colors?: string[];
  type?: string;
}
