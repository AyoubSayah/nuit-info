const CartRouter = {
  path: "/cart",
  name: "Cart",
  component: () => import("../Cart.vue"),
};
export default CartRouter;
