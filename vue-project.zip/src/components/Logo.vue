<template>
  <h1
    class="ml-[50%] mb-3 w-max translate-x-[-50%] rounded-xl border-4 border-solid p-4 text-3xl font-bold uppercase text-theme-primary md:mb-8 md:text-4xl"
  >
    LookUnique
  </h1>
</template>
<script lang="ts" setup></script>
