<template>
  <div
    class="fixed top-0 left-0 z-10 h-full w-full backdrop-brightness-75"
  ></div>
</template>
<script lang="ts" setup></script>
