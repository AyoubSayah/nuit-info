module.exports = {
  plugins: {
    tailwindcss: { config: "theme/tailwind.config.js" },
    autoprefixer: {},
  },
};
